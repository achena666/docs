# 阶段二：上机复测流水线（实战验证版）

目标环境：昇腾 910B 系列服务器/容器，aarch64，通常无 sudo，多用户共享。全程命令可在本机经 SSH 远程执行（`scripts/ssh_run.py`）。

## 0. 前置：复测环境从哪来（没有现成 NPU 服务器时）

| 渠道 | 要点 |
|---|---|
| **HiDevLab**（hidevlab.huawei.com） | 实名注册 → 申请算力（写明用途，如"CANN 社区任务算子验收复测"）→ 通过后 100 小时免费卡时。创建实例时选 **aarch64 架构 + 满足任务书的 CANN 版本镜像 + 910B 单卡**（单卡够用）。SSH 地址与密码由平台派发 |
| **CANNLab** | A2/A3 算力，登录即送 100 小时，可积分换时长 |
| **任务方/交付方派发的容器** | 直接使用派发的 SSH 信息 |

注意事项：
- **不用时务必关机/断开**，卡时连续计算
- 容器内只有 `/workspace/user_data` 一类挂载目录在重启后保留，重要产物放这里并同步备份到本地
- 实例 CANN 版本不满足任务书时，按第 1 节用户级安装正确版本即可，不必换实例

## 0b. Docker 容器内跑验收（标准验收镜像）

宿主机有 Docker 时，可以把验收环境固化成标准镜像（基础镜像用官方 CANN 系镜像，如 `quay.nju.edu.cn/ascend/vllm-ascend:v0.28.0.rc1`，自带 CANN 9.1.0 + torch_npu 2.10.0.post4 + gcc/cmake/git）。

**标准启动命令**（实战验证过的完整 NPU 透传配置，缺一个都会初始化失败）：

```bash
docker run --rm --user root \
  --device /dev/davinci<N> \
  --device /dev/davinci_manager \
  --device /dev/devmm_svm \
  --device /dev/hisi_hdc \
  -v /usr/local/Ascend/driver:/usr/local/Ascend/driver \
  -v /usr/local/dcmi:/usr/local/dcmi \
  -v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi \
  -v <提交代码目录>:/work/submission \
  -v <任务包目录>:/work/task_package:ro \
  -v <输出目录>:/work/output \
  cann-acceptance:9.1.0 \
  bash -c "source /usr/local/Ascend/cann-9.1.0/set_env.sh && <验收命令>"
```

**四个必踩坑（都已踩过）**：

| 坑 | 现象 | 原因与处置 |
|---|---|---|
| 只映射 davinci0 | aclInit 报 507008，"Failed to obtain the SOC version" | 必须同时映射 davinci_manager（管理通道）+ devmm_svm（设备内存）+ hisi_hdc（通信通道）三个设备 |
| 不挂 driver 目录 | 报驱动内部错误 | `-v /usr/local/Ascend/driver:/usr/local/Ascend/driver` 让容器内 CANN 匹配宿主机驱动 |
| 报 Busy(E10005) resources busy | 换卡即可 | davinciN 被其他容器/进程持有（宿主机 npu-smi 可能看不到容器内进程），`npu-smi info` 找 AICore 0% 的卡换卡号重试 |
| 容器内用户无权限 | 设备文件属组 HwHiAiUser `crw-rw----` | 加 `--user root` 或把用户加入 HwHiAiUser 组 |

验证命令（容器内 NPU 真实计算）：

```bash
python3 -c "import torch,torch_npu; x=torch.randn(4,4).npu(); (x@x).cpu(); print('NPU OK in docker')"
```

选卡看 `npu-smi info` 三列：**Health=OK、AICore(%)≈0、HBM-Usage 占用少**。910B 空闲功耗 90~100W 正常，满载 300W+。

## 0b. 远程执行基础设施

本机准备 paramiko（`pip install paramiko`），用 `scripts/ssh_run.py`：

```bash
python ssh_run.py <host> <port> <user> <password-or-key> '<command>'
```

批量长任务模式：服务器端 `nohup bash -c '...' < /dev/null > log 2>&1 &` 启动，本机轮询日志关键字（阶段标记/EXIT 码）直到完成。**stdin 不重定向会导致 SSH 通道永久挂死。**

## 1. 环境准备：CANN 任务书版本

检查：`cat /usr/local/Ascend/*/version.info` 或 `npu-smi info`。

版本不足时**用户级安装**（以下以 9.1.0 为例，**版本号按任务书要求替换**，架构按服务器实际 aarch64/x86_64 替换）：

```bash
mkdir -p ~/cann_pkg && cd ~/cann_pkg
wget https://ascend-repo.obs.cn-east-2.myhuaweicloud.com/CANN/CANN%209.1.0/Ascend-cann-toolkit_9.1.0_linux-aarch64.run
wget https://ascend-repo.obs.cn-east-2.myhuaweicloud.com/CANN/CANN%209.1.0/Ascend-cann-910b-ops_9.1.0_linux-aarch64.run
yes | bash Ascend-cann-toolkit_9.1.0_linux-aarch64.run --install
yes | bash Ascend-cann-910b-ops_9.1.0_linux-aarch64.run --install
echo 'source $HOME/Ascend/cann/set_env.sh' >> ~/.bashrc
```

- 无需登录昇腾账号，OBS 直链可用
- 与系统自带 CANN 共存，set_env.sh 切换
- ops 包含 libhccl.so，可顺带修复 torch_npu 报 libhccl.so 缺失的问题
- 驱动为宿主机共享，不可升级也不需要升级
- 验证：`source ~/Ascend/cann/set_env.sh && python -c "import torch,torch_npu; x=torch.randn(4,4).npu(); (x@x).cpu(); print('NPU OK')"`

### 1b. Python 栈：venv + torch_npu 版本兼容

torch_npu 与 CANN 有严格版本对照（装错必报 libhccl.so 缺失等错）。已验证组合：

| CANN | torch_npu（已验证） | 说明 |
|---|---|---|
| 9.0.0 | 2.7.1.post4 / 2.8.0.post4 / 2.9.0.post2 / 2.10.0 | 官方 COMPATIBILITY.md 口径 |
| 9.1.0 | 2.8.0.post4（实测通过）/ 2.8.0.post5（实测**不**兼容）/ 2.10.0.post6 | post5 是 9.1.x 专用版但同系共存仍需对号 |

创建（aarch64 上 pip 走清华源）：

```bash
python3 -m venv ~/venv && source ~/venv/bin/activate
pip install torch --index-url https://pypi.tuna.tsinghua.edu.cn/simple          # CPU 版即可
pip install torch-npu==2.8.0.post4 --index-url https://pypi.tuna.tsinghua.edu.cn/simple
pip install numpy ml_dtypes pytest                                              # golden 对比与回归所需
```

## 2. 获取代码与一致性核查

```bash
git clone <repo_url> <workdir> && cd <workdir>
git checkout <验收基线commit>
git diff --stat <材料引用commit> <tip> -- <算子目录> <交付目录>   # 期望为空或仅文档
```

记录 `git rev-parse HEAD` 供报告引用。

## 3. 构建

```bash
source ~/Ascend/cann/set_env.sh   # 或系统 set_env.sh，指向 ≥ 任务书版本
source <venv>/bin/activate
bash build.sh --pkg --experimental --ops=<算子名> --soc=ascend910b -j8
```

- 产物在 `build_out/*.run`
- **坑**：报 `Populate sub_pkg error / make package failed` 且错误串在仓库中搜不到 → 旧 CMake 缓存所致，`rm -rf build build_out` 后重建
- 构建期第三方依赖（abseil/protobuf/eigen）会自动拉取，需外网

## 4. 安装

```bash
chmod +x build_out/*.run
mkdir -p ~/kv_opp && build_out/*.run --quiet --install-path=$HOME/kv_opp
source ~/kv_opp/vendors/<vendor_name>/bin/set_env.bash   # 路径以安装输出为准
```

## 5. 精度测试（权威口径：任务包原版 golden 逐字节）

优先使用提交方自带测试程序（读其 task_submission/1 自验证步骤说明.md 与 examples/README）：

1. 编译 examples（g++ 头文件/库路径指向**实际 CANN 安装位置**与自定义算子 op_api 目录，链接 `-lcust_opapi -lnnopbase -lascendcl`）
2. 运行提交方测试程序，**落盘真实输入与 NPU 输出**（具体二进制名、环境变量、dump 目录约定以提交方 README/自验说明为准。示例——Twilight 提交的约定：`KVQT_CPU_GOLDEN_STRICT=0 KVQT_DUMP_DIR=<dump目录> ./test_kvqt`；其他提交方各有自己的入口与变量名，不可照搬）
3. 用任务包**原版** golden.py 对同一 dump 逐字节对比：
   - 提交方自带对比脚本时优先用（如 `tests/validation/compare_task_golden.py --task-dir <任务包> --dump-dir <dump目录>`）
   - **无现成脚本时的通用兜底**：import 任务包 golden.py 的期望计算函数，对 dump 中每个 `<case>.input_*.bin` 计算参考输出，再与 `<case>.output_*.bin` 做 `np.array_equal` / 逐字节比对。约 20 行 numpy 即可实现，核心是：

```python
import importlib.util, numpy as np
spec = importlib.util.spec_from_file_location("golden", "<任务包>/golden.py")
calc = importlib.util.module_from_spec(spec); spec.loader.exec_module(calc).calc_expect_func
expected = calc(kv, rotation, qjl, mse_bits)          # 与 golden.py 签名一致
actual = np.fromfile("<dump>/case_x.output_quant_idx.bin", dtype=np.uint8)
print("identical" if np.array_equal(expected[0].view(np.uint8).reshape(-1), actual) else "MISMATCH")
```

```bash
python3 <算子>/tests/validation/compare_task_golden.py --task-dir <任务包> --dump-dir <dump目录>
```

- 逐项 `[PASS] ... bytes identical` 且退出码 0 = 通过
- 提交方自带 CPU 宿主参考的 mismatch（idx ±1 / qjl 单 bit 翻转）是归约顺序 tie，属诊断信息，**不定性为算子错误**——权威判据是任务包 NPU golden
- golden.py 依赖 torch_npu/numpy/ml_dtypes，需在 venv 中执行
- 记录 case.json / golden.py / 输入矩阵的 SHA-256，写进报告附录

## 6. 质量门禁

从 dump 的真实输入输出按任务书 §3.2 指标逐条计算（阈值为 kv_cache 任务示例，通用时以任务书原文为准）：

- 逐向量最大相对 MSE：`MSE / ||x||² < 0.05`
- 内积相对误差 P95：`|<q,x̂>-<q,x>| / |<q,x>| < 0.1`（任务书未定义 Query 时，q=x 为惯用回归协议，报告中注明）

## 7. 性能测试

提交方 benchmark 或自写：每 case 预热（10 次）+ 正式采样（≥30 次），计时含 ACLNN launch 与同步，统计 median 与 P90：

```
加速比 = 任务书 eager baseline (µs) / NPU P90 (µs) ≥ 10
```

- 明确记录统计口径（P90 / 中位数），不同口径数值不同但结论应一致
- 共享设备性能余量 <10% 的 case 建议低负载时段复测一次确认稳定
- 与提交方自验数值偏差在 ±5% 内属环境负载差异

## 8. 交叉验证与产出

- 同一提交存在多份验收报告时，对比测试范围与数值；口径不同不可混算
- 全部通过 → 按 report-template.md 第一节生成 `<提交人><分支名>验收报告.md`
- 失败 → 按第二节生成退回意见，附日志绝对路径与退出码

## 已知坑速查

| 现象 | 原因 | 处置 |
|---|---|---|
| SSH 后台任务卡死 | 后台进程占用 stdin/stdout | `< /dev/null` + 输出重定向到文件 |
| .run 安装卡住 | EULA 交互确认 | `yes | bash xxx.run --install` |
| 构建报 Populate sub_pkg error | 旧 CMake 缓存 | `rm -rf build build_out` 重建 |
| npm/下载慢 | 默认源境外 | npmmirror / 华为 OBS 直链 |
| torch_npu 报 libhccl.so 缺失 | 系统 CANN 安装不完整 | 安装官方 ops 包（含完整 libhccl）后 source 其 set_env.sh |
| SSH 写 .bashrc 后 PATH 异常 | `$PATH` 被远程 shell 提前展开 | 用 python 内嵌命令或 sed 直改，不经 echo |
