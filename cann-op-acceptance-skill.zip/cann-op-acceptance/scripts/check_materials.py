#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""材料合规自动检查器：对本地算子提交仓库做案头审查取证。

用法:
    python check_materials.py --repo <本地仓库路径> --op-dir <算子相对路径>

检查项（对应 material-checklist.md）:
  A1  task_submission 7 件完整性
  A2  OpDef dtype 注册列表（供与任务书接口表比对）
  A3  测试代码随包情况 + README
  B1  自测报告 xlsx 内嵌截图数量
  B2  材料中引用的 40 位 commit id 提取
  附加 README.md 存在性检查

输出: 结构化审查报告（stdout），❌/⚠️/✅ 逐项列证据。
"""
import argparse
import os
import re
import sys

try:
    import openpyxl
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

EXPECTED_FILES = [
    "1 自验证步骤说明.md",
    "2.1 精度自验证报告.xlsx", "2.2 精度自验证日志.log",
    "3.1 性能自验证报告.xlsx", "3.2 性能自验证日志.log",
    "4.1 内存自验证报告.xlsx", "4.2 内存自验证日志.log",
]

COMMIT_RE = re.compile(r"\b[0-9a-f]{40}\b")
RESULT = {"A1": None, "A2": None, "A3": None, "B1": None, "B2": None}


def find_task_submission(repo):
    hits = []
    for root, dirs, files in os.walk(repo):
        dirs[:] = [d for d in dirs if d not in (".git", "build", "build_out")]
        if os.path.basename(root) == "task_submission":
            hits.append(root)
    return hits


def check_a1(repo, op_dir):
    hits = find_task_submission(repo)
    if not hits:
        RESULT["A1"] = ("❌", "未找到 task_submission 目录（搜索过仓库全树）")
        return
    best = max(hits, key=lambda p: len(os.listdir(p)))
    present = set(os.listdir(best))
    missing = [f for f in EXPECTED_FILES if f not in present]
    extra_note = f"（共 {len(hits)} 处 task_submission，取文件最多处）" if len(hits) > 1 else ""
    if missing:
        RESULT["A1"] = ("❌", f"{best} 缺少: {missing} {extra_note}")
    else:
        RESULT["A1"] = ("✅", f"{best} 7 件齐全 {extra_note}")


def check_a2(repo, op_dir):
    op_host = os.path.join(repo, op_dir, "op_host")
    def_files = []
    if os.path.isdir(op_host):
        def_files = [os.path.join(op_host, f) for f in os.listdir(op_host)
                     if f.endswith("def.cpp")]
    if not def_files:
        RESULT["A2"] = ("❌", f"{op_host} 下未找到 *def*.cpp")
        return
    src = open(def_files[0], encoding="utf-8", errors="replace").read()
    print("--- OpDef dtype 注册明细（与任务书接口表比对） ---")
    # dtype 变量表: const std::initializer_list<ge::DataType> kvTypes = {ge::DT_BF16, ...}
    var_map = {}
    for m in re.finditer(r"initializer_list<ge::DataType>\s+(\w+)\s*=\s*\{([^}]*)\}", src):
        var_map[m.group(1)] = re.findall(r"ge::DT_(\w+)", m.group(2))
    for m in re.finditer(r'(Input|Output)\("(\w+)"\)([^;]*?);', src, re.S):
        kind, name, body = m.group(1), m.group(2), m.group(3)
        dtypes = re.findall(r"ge::DT_(\w+)", body)
        if not dtypes:
            for ident in re.findall(r"\b(\w+)\b", body):
                if ident in var_map:
                    dtypes = var_map[ident]
                    break
        tag = "I/O" if kind == "Input" else "OUT"
        print(f"  [{tag}] {name}: {dtypes if dtypes else '(未识别)'}")
    attr = re.search(r'Attr\("(\w+)"\)[^;]*?Int\((\d+)\)', src)
    if attr:
        print(f"  [ATTR] {attr.group(1)}: 默认 {attr.group(2)}")
    RESULT["A2"] = ("⚠️", "dtype 列表已打印，需人工对照任务书 §2.3 接口表"
                          "（矩阵需 FP32/BF16 双支持、标量需 FP16/BF16 双支持、mse_bits 默认 3）")


def check_a3(repo, op_dir):
    op_full = os.path.join(repo, op_dir)
    test_markers = []
    for sub in ("tests", "examples", "test"):
        p = os.path.join(op_full, sub)
        if os.path.isdir(p):
            n = sum(len(fs) for _, _, fs in os.walk(p))
            test_markers.append(f"{sub}/({n} 文件)")
    scripts = [f for f in os.listdir(op_full) if f.endswith((".sh", ".py"))
               and "run" in f.lower()] if os.path.isdir(op_full) else []
    readme = os.path.exists(os.path.join(op_full, "README.md"))
    if test_markers:
        RESULT["A3"] = ("✅", f"测试代码随包: {', '.join(test_markers)}"
                              f"{'; 脚本: ' + ', '.join(scripts) if scripts else ''}"
                              f"{'; README ' + ('存在' if readme else '缺失')}")
    else:
        RESULT["A3"] = ("❌", "算子目录内无 tests/examples 测试代码"
                              f"{'; README ' + ('存在' if readme else '缺失')}；"
                              "若复测脚本在其他分支，验收人按材料无法复现")


def check_b1(repo):
    hits = find_task_submission(repo)
    if not hits:
        RESULT["B1"] = ("⚠️", "无 task_submission 可检查截图")
        return
    best = max(hits, key=lambda p: len(os.listdir(p)))
    if not HAS_OPENPYXL:
        print("（未安装 openpyxl，跳过截图检查；pip install openpyxl）")
        RESULT["B1"] = ("⚠️", "openpyxl 未安装，跳过截图检查")
        return
    total, details = 0, []
    for f in sorted(os.listdir(best)):
        if f.endswith(".xlsx") and re.match(r"^[23]\.", f):
            try:
                wb = openpyxl.load_workbook(os.path.join(best, f))
                ws = wb.active
                n = len(getattr(ws, "_images", []))
                total += n
                details.append(f"{f}:{n}图")
                print(f"[B1] {f}: 图片数={n} {'✅' if n > 0 else '⚠️ 无嵌入截图（任务书模板要求截图）'}")
            except Exception as e:
                print(f"[B1] {f}: 解析失败 {e}")
    RESULT["B1"] = ("✅" if total > 0 else "⚠️",
                    f"精度/性能报告截图合计 {total} 张（{'; '.join(details)}）")


def check_b2(repo, op_dir):
    ids = set()
    for root, dirs, files in os.walk(repo):
        dirs[:] = [d for d in dirs if d not in (".git", "build", "build_out")]
        for f in files:
            if f.endswith((".md", ".log", ".txt")):
                try:
                    txt = open(os.path.join(root, f), encoding="utf-8",
                               errors="replace").read()
                    ids.update(COMMIT_RE.findall(txt))
                except OSError:
                    pass
    if ids:
        print(f"[B2] 材料中引用的 commit id（{len(ids)} 个，与提交 tip 人工比对）:")
        for c in sorted(ids):
            print(f"     {c}")
        RESULT["B2"] = ("⚠️", "见上方列表，需与提交 tip 比对是否一致")
    else:
        RESULT["B2"] = ("⚠️", "材料中未提取到 40 位 commit id")


def check_a4_hint(repo, hits):
    """辅助探测自验数据来源（generate_data.py 官方引用 vs 自造种子）。仅提示，判定人工做出。"""
    if not hits:
        return
    best = max(hits, key=lambda p: len(os.listdir(p)))
    doc = os.path.join(best, EXPECTED_FILES[0])
    if not os.path.exists(doc):
        return
    txt = open(doc, encoding="utf-8", errors="replace").read()
    official = "generate_data.py" in txt or "官方" in txt and "数据" in txt
    selfgen = re.search(r"seed\s*[=:]\s*\d+", txt) or "确定性生成" in txt or "自造" in txt
    print("[A4辅助] 自验证说明数据源线索：")
    if official:
        print("     - 提及 generate_data.py/官方数据（需核对是否任务方最新版）")
    if selfgen:
        print("     - 检测到自造种子/确定性生成表述（seed=… 或 '确定性生成'）→ 疑似 A4 硬伤")
    if not official and not selfgen:
        print("     - 未检测到明确数据源表述，人工确认")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--op-dir", required=True,
                    help="算子相对路径，如 experimental/attention/kv_cache_turbo_quant")
    args = ap.parse_args()

    print(f"=== 材料合规检查: {args.repo} ===")
    check_a1(args.repo, args.op_dir)
    check_a2(args.repo, args.op_dir)
    check_a3(args.repo, args.op_dir)
    hits = find_task_submission(args.repo)
    check_a4_hint(args.repo, hits)
    check_b1(args.repo)
    check_b2(args.repo, args.op_dir)

    print("\n=== 审查汇总 ===")
    for k in ("A1", "A2", "A3", "B1", "B2"):
        item = RESULT.get(k)
        if item is None:
            item = ("⚠️", "未执行（前置检查未通过）")
        mark, msg = item
        print(f"[{k}] {mark} {msg}")
    print("\n人工复核项（脚本不可判定）: 自验数据源是否官方最新 generate_data.py；"
          "Ascend-CANN 开发者邀请凭证；§3.2/§3.3 结论口径；设计文档 PR 状态。")


if __name__ == "__main__":
    main()
