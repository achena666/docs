#!/usr/bin/env python3
"""SSH 远程命令执行助手（paramiko）。

用法:
    python ssh_run.py <host> <port> <user> <password> '<command>'
    python ssh_run.py <host> <user> <password> '<command>'          # 端口默认 22
    python ssh_run.py <host> <user> <keyfile> --key '<command>'     # 私钥认证

输出: stdout / [STDERR] stderr / [EXIT:code]，退出码与远程命令一致。
依赖: pip install paramiko
"""
import sys
import paramiko


def main():
    args = sys.argv[1:]
    if len(args) < 4:
        print(__doc__)
        sys.exit(2)

    host = args[0]
    command = args[-1]
    use_key = "--key" in args
    if use_key:
        keyfile = args[args.index("--key") - 1]
        user, password = args[1], args[2]
        port = 22
    elif len(args) >= 5 and args[1].isdigit():
        port, user, password = int(args[1]), args[2], args[3]
    else:
        port, user, password = 22, args[1], args[2]

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, port=port, username=user,
                   password=None if use_key else password,
                   key_filename=keyfile if use_key else None, timeout=15)
    stdin, stdout, stderr = client.exec_command(command, timeout=600)
    out = stdout.read().decode("utf-8", errors="replace")
    err = stderr.read().decode("utf-8", errors="replace")
    code = stdout.channel.recv_exit_status()
    if out:
        print(out)
    if err.strip():
        print("[STDERR]", err, file=sys.stderr)
    print(f"[EXIT:{code}]")
    client.close()
    sys.exit(code)


if __name__ == "__main__":
    main()
